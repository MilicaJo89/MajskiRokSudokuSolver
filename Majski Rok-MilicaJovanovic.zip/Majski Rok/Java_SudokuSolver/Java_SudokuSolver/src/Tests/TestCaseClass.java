package Tests;

import nl.elridge.sudoku.controller.ButtonController;
import nl.elridge.sudoku.controller.SudokuController;
import nl.elridge.sudoku.model.Game;
import nl.elridge.sudoku.view.SudokuPanel;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import nl.elridge.sudoku.model.UpdateAction;
import nl.elridge.sudoku.view.ButtonPanel;
import nl.elridge.sudoku.view.Field;
import nl.elridge.sudoku.view.Sudoku;
import javax.swing.*;
import java.awt.*;
import static org.junit.Assert.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;


public class TestCaseClass extends Base {
	

    @Test
    public void TestActionPerformed() {
        Game game = new Game();
        ButtonController buttonController = new ButtonController(game);
       
        ActionEvent event = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "New");
        String CommandName = event.getActionCommand();
        buttonController.actionPerformed(event);
        Assert.assertEquals(CommandName, "New");

        ActionEvent event1 = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "Check");
        String CommandName1 = event1.getActionCommand();
        buttonController.actionPerformed(event1);
        Assert.assertEquals(CommandName1, "Check");

        ActionEvent event2 = new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "Help on");
        String CommandName2 = event2.getActionCommand();
        game.setHelp(true);
        Assert.assertEquals(CommandName2, "Help on");
    }


    @Test
    public void TestMouseClickedWithValidCoordinates() {
        Game game = new Game();
        SudokuPanel sudokuPanel = new SudokuPanel();
        SudokuController sudokuController = new SudokuController(sudokuPanel, game);
        MouseEvent event = new MouseEvent(sudokuPanel, MouseEvent.MOUSE_CLICKED,
                System.currentTimeMillis(), 0,
                50, 50, 1, false);

        sudokuController.mouseClicked(event); }

    @Test
    public void TestMouseClickedWithInvalidCoordinates() {
        Game game = new Game();
        SudokuPanel sudokuPanel = new SudokuPanel();
        SudokuController sudokuController = new SudokuController(sudokuPanel, game);
        MouseEvent event = new MouseEvent(sudokuPanel, MouseEvent.MOUSE_CLICKED,
                System.currentTimeMillis(), 0,
                500, 500, 1, false);

        sudokuController.mouseClicked(event);
    }

    @Test
    public void TestMouseEntered() throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        Game game = new Game();
        SudokuPanel sudokuPanel = new SudokuPanel();
        SudokuController sudokuController = new SudokuController(sudokuPanel, game);
        MouseEvent event = new MouseEvent(sudokuPanel, MouseEvent.MOUSE_ENTERED,
                System.currentTimeMillis(), 0,
                10, 10, 0, false);

        Method method = SudokuController.class.getDeclaredMethod("mouseEntered", MouseEvent.class);

        method.invoke(sudokuController, event);

    }

    @Test
    public void TestMouseExited() {
        Game game = new Game();
        SudokuPanel sudokuPanel = new SudokuPanel();
        SudokuController sudokuController = new SudokuController(sudokuPanel, game);
        MouseEvent event = new MouseEvent(sudokuPanel, MouseEvent.MOUSE_EXITED,
                System.currentTimeMillis(), 0,
                10, 10, 0, false);
        sudokuController.mouseExited(event);

    }
    
    
    @Test
    public void TestNewGame() {
        Game game = new Game();
        assertEquals(game.isHelp(), true);
        boolean[][] check = new boolean[9][9];
        assertEquals(9, check.length);
        assertEquals(9, check[0].length);
        for (int i = 0; i < check.length; i++) {
            for (int j = 0; j < check[i].length; j++) {
                assertFalse(check[i][j]);
                //  check[i][j] = false;
            }
        }
    }

    @Test
    public void TestSetHelp() {
        Game game = new Game();
        game.setHelp(false);
        assertEquals(game.isHelp(), false);
    }

    @Test
    public void TestGetHelp() {
        Game game = new Game();
        game.setHelp(true);
        assertEquals(game.isHelp(), true);
    }

    @Test
    public void TestSetSelectedNumber() {
        Game game = new Game();
        game.setSelectedNumber(5);
        assertEquals(game.getSelectedNumber(), 5);
    }

    @Test
    public void TestCheckGame() {
        int[][] game = new int[9][9];
        int[][] solution = new int[9][9];
        boolean[][] check = new boolean[9][9];

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                game[i][j] = 0 * 9 + j * 1;
                solution[i][j] = 0 * 9 + j * 1;

            }
        }
        Game g = new Game();
        g.checkGame();
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 9; j++) {
                check[i][j] = game[i][j] == solution[i][j];
                assertEquals(check[i][j], true);
            }
        }

    }

    @Test
    public void TestSetAndGetNumber() {
        Game game = new Game();
        game.setNumber(5, 5, 7);
        assertEquals(game.getNumber(5, 5), 7);

    }

    @Test
    public void TestCheckValidFalse() {
        Game game = new Game();
        int[][] fields = {
                {8, 2, 7, 1, 5, 4, 3, 9, 6},
                {9, 6, 5, 3, 2, 7, 1, 4, 8},
                {3, 4, 1, 6, 8, 9, 7, 5, 2},
                {5, 9, 3, 4, 6, 8, 2, 7, 1},
                {4, 7, 2, 5, 1, 3, 6, 8, 9},
                {6, 1, 8, 9, 7, 2, 4, 3, 5},
                {7, 8, 6, 2, 3, 5, 9, 1, 4},
                {1, 5, 4, 7, 9, 6, 8, 2, 3},
                {2, 3, 9, 8, 4, 1, 5, 6, 7}
        };

        int x = 0;
        int y = 0;
        assertFalse(game.isCheckValid(x, y));

    }

    @Test
    public void TestCheckValidTrue() {
        Game game = new Game();
        int[][] fields = {
                {8, 2, 7, 1, 5, 4, 3, 9, 6},
                {9, 6, 5, 3, 2, 7, 1, 4, 8},
                {3, 4, 1, 6, 8, 9, 7, 5, 2},
                {5, 9, 3, 4, 6, 8, 2, 7, 1},
                {4, 7, 2, 5, 1, 3, 6, 8, 9},
                {6, 1, 8, 9, 7, 2, 4, 3, 5},
                {7, 8, 6, 2, 3, 5, 9, 1, 4},
                {1, 5, 4, 7, 9, 6, 8, 2, 3},
                {2, 3, 9, 8, 4, 1, 5, 6, 7}
        };
        int x = 0;
        int y = 0;
        assertTrue(game.isCheckValid(x, y));
    }

    @Test
    public void isSelectedNumberACandidateTrue() {
        Game game = new Game();
        game.setSelectedNumber(5);
        for (int y = 0; y < 9; y++) {
            for (int x = 0; x < 9; x++) {
                if (game.isSelectedNumberCandidate(x, y) && game.isCheckValid(x, y)) {
                    game.setNumber(x, y, game.getSelectedNumber());
                    assertTrue(game.isCheckValid(x, y));
                }
            }

        }

    }

    @Test
    public void isSelectedNumberACandidateFalse() {
        Game game = new Game();
        game.setSelectedNumber(15);
        for (int y = 0; y < 9; y++) {
            for (int x = 0; x < 9; x++) {
                if (game.isSelectedNumberCandidate(x, y) && game.isCheckValid(x, y)) {
                    game.setNumber(x, y, game.getSelectedNumber());
                    assertFalse(game.isCheckValid(x, y));
                }
            }

        }
    }
    
    
    @Test
    public void TestStartGui() {
        Sudoku sudoku = new Sudoku();
        sudoku.main(null);
        assertTrue(sudoku.getContentPane().getLayout() instanceof BorderLayout);
        assert sudoku != null;


    }


    @Test
    public void TestGetFieldX() {
        int expectedX = 7;
        Field field = new Field(expectedX, 7);
        assertEquals(expectedX, field.getFieldX());
    }

    @Test
    public void TestGetFieldY() {
        int expectedY = 8;
        Field field = new Field(8, expectedY);
        assertEquals(expectedY, field.getFieldY());

    }
    
    @Test
    public void TestSudokuConstructor() {
        Sudoku sudoku = new Sudoku();
        assertEquals("Sudoku", sudoku.getTitle());
        assertEquals(WindowConstants.EXIT_ON_CLOSE, sudoku.getDefaultCloseOperation());
        assertTrue(sudoku.getContentPane().getLayout() instanceof BorderLayout);
        assert sudoku != null;

    }


    @Test
    public void TestSudokuPanelUpdateMethod() {
        SudokuPanel sudokuPanel = new SudokuPanel();
        Game game = new Game();
        
        //check
        boolean setCheckCalled = false;
        UpdateAction action1 = UpdateAction.CHECK;
        sudokuPanel.update(game, action1);
        setCheckCalled = true;
        assertTrue(setCheckCalled);
        
        //selected_field
        boolean setSelectedCandidatesCalled = false;
        UpdateAction action3 = UpdateAction.CANDIDATES;
        sudokuPanel.update(game, action3);
        setSelectedCandidatesCalled = true;
        assertTrue(setSelectedCandidatesCalled);

        //new_game
        boolean setGameCalled = false;
        UpdateAction action = UpdateAction.NEW_GAME;
        sudokuPanel.update(game, action);
        setGameCalled = true;
        assertTrue(setGameCalled);

        //selected_number
        boolean setSelectedNumberCalled = false;
        UpdateAction action2 = UpdateAction.SELECTED_NUMBER;
        sudokuPanel.update(game, action2);
        setSelectedNumberCalled = true;
        assertTrue(setSelectedNumberCalled);

        //candidates
        boolean setHelpCalled = false;
        UpdateAction action4 = UpdateAction.HELP;
        sudokuPanel.update(game, action4);
        setHelpCalled = true;
        assertTrue(setHelpCalled);

    }

    @Test
    public void TestButtonPanelUpdateMethod() {
        ButtonPanel buttonPanel = new ButtonPanel();
        Game game = new Game();
        
        
        //check
        boolean setCheckCalled = false;
        int bgNumbersCalculator;
        UpdateAction action1 = UpdateAction.CHECK;
        buttonPanel.update(game, action1);
        setCheckCalled = true;
        assertTrue(setCheckCalled);
        if (setCheckCalled = true) {
            bgNumbersCalculator = 0;
        } else {
            bgNumbersCalculator = 1;
        }
        assertEquals(0, bgNumbersCalculator);
        

        //new_game
        boolean setGameCalled = false;
        UpdateAction action = UpdateAction.NEW_GAME;
        buttonPanel.update(game, action);
        setGameCalled = true;
        assertTrue(setGameCalled);

    }
     
    private Game game;
    
    @Before
    public void setUp() {
        // Create a sample game object for testing
        game = new Game();
        // Set up the game with sample numbers
        game.setNumber(0, 0, 5);
        game.setNumber(1, 0, 3);
        game.setNumber(4, 0, 7);
        game.setNumber(0, 1, 6);
        game.setNumber(3, 1, 1);
        game.setNumber(4, 1, 9);
        game.setNumber(5, 1, 5);
        game.setNumber(1, 2, 9);
        game.setNumber(2, 2, 8);
        game.setNumber(7, 2, 6);
        game.setNumber(0, 3, 8);
        game.setNumber(4, 3, 6);
        game.setNumber(8, 3, 3);
        game.setNumber(0, 4, 4);
        game.setNumber(3, 4, 8);
        game.setNumber(5, 4, 3);
        game.setNumber(8, 4, 1);
        game.setNumber(0, 5, 7);
        game.setNumber(4, 5, 2);
        game.setNumber(8, 5, 6);
        game.setNumber(1, 6, 6);
        game.setNumber(6, 6, 2);
        game.setNumber(7, 6, 8);
        game.setNumber(3, 7, 4);
        game.setNumber(4, 7, 1);
        game.setNumber(5, 7, 9);
        game.setNumber(8, 7, 5);
        game.setNumber(4, 8, 8);
        game.setNumber(7, 8, 7);
        game.setNumber(8, 8, 9);
    }
    
    
    @Test
    public void testCopyArr() {
        int[][] sourceArray = {
            {5, 3, 0, 0, 7, 0, 0, 0, 0},
            {6, 0, 0, 1, 9, 5, 0, 0, 0},
            {0, 9, 8, 0, 0, 0, 0, 6, 0},
            {8, 0, 0, 0, 6, 0, 0, 0, 3},
            {4, 0, 0, 8, 0, 3, 0, 0, 1},
            {7, 0, 0, 0, 2, 0, 0, 0, 6},
            {0, 6, 0, 0, 0, 0, 2, 8, 0},
            {0, 0, 0, 4, 1, 9, 0, 0, 5},
            {0, 0, 0, 0, 8, 0, 0, 7, 9}
        };

        Base baseTest = new Base();}
    
    @Test
    public void testGenerateGameArray() {
        Game game = new Game();
        // Assume that the getNumber method is implemented correctly
        game.setNumber(0, 0, 5);
        game.setNumber(1, 0, 3);
        game.setNumber(4, 0, 7);
        game.setNumber(8, 0, 6);

        game.setNumber(0, 1, 6);
        game.setNumber(3, 1, 1);
        game.setNumber(4, 1, 9);
        game.setNumber(5, 1, 5);
        game.setNumber(8, 1, 8);
       

        int[][] expectedArray = {
                {5, 3, 0, 0, 7, 0, 0, 0, 6},
                {6, 0, 0, 1, 9, 5, 0, 0, 8},
                {0, 9, 8, 0, 0, 0, 0, 6, 0},
                {8, 0, 0, 0, 6, 0, 0, 0, 3},
                {4, 0, 0, 8, 0, 3, 0, 0, 1},
                {7, 0, 0, 0, 2, 0, 0, 0, 6},
                {0, 6, 0, 0, 0, 0, 2, 8, 0},
                {0, 0, 0, 4, 1, 9, 0, 0, 5},
                {0, 0, 0, 0, 8, 0, 0, 7, 9}
        };
 
    }
   
}
 